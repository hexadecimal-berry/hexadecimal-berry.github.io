﻿module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    if(message.author.id !== '473107978375921674') return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You don't have Permission to Execute this Command`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    if(isNaN(Args[0])) return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: 'Provide an amount of Messages to Purge',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    if(Args[0] < 1) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: 'I am unable to Delete **' + Args[0] + '** Messages',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    if(Args[0] > 100) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: 'Provide a Number less than ** 100 **',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });
    
    message.channel.bulkDelete(Args[0]).then(MSG => {
        message.channel.send({embed: {
            color: 0x00FF00,
            title: 'Purging the Messages...',
            description: `Deleted **${MSG.size}/${Args[0]}** Messages`,
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }}
        }).then((MSG) => {
            setTimeout(() => { MSG.delete(); }, 25000);
        });
    });
};