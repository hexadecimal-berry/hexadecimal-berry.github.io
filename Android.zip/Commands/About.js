module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    message.channel.send({embed: {
        color: 0x00FF00,
        title: 'Inspirational. Creative. Innovative.',
        thumbnail: {
            url: Android.user.avatarURL(),
        },
        description: `System: Windows 10 Pro x64
        \n\
        Android is a Bot created by TheGreekDev.
        It all started with TechnoBot in 2017...
        TechnoBot, a Bot with lot of limitations
        and of course discontinued by the Owner.
        After 3 Years, something came in mind of
        TheGreekDev, a better and new Version of
        TechnoBot. Along with a new name for it,
        Android. It's now the replacement of his
        old Bot named TechnoBot. Let's begin now
        \n\
        ***For the Commands, type in !Help***`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
};