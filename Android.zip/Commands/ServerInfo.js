module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    message.channel.send({embed: {
        color: 0x00FF00,
        title: 'Showing Server Info for: ' + message.guild.name,
        thumbnail: {
            url: message.guild.iconURL(),
        },
        description: `\n\
        **Server Owner:** ${message.guild.owner}
        **Server IDs:** ${message.guild.id}
        **Server Region:** ${message.guild.region}
        **Total Members:** ${message.guild.memberCount}
        **Total Channels:** ${message.guild.channels.cache.size}
        **Total Roles:** ${message.guild.roles.cache.size - 1}
        **Verify Level:** ${message.guild.verificationLevel}`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
};