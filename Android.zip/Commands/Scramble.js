module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    var Scramble = [
        ":x: :x: :x: :x:", ":x: :x: :x: :o:", ":x: :x: :o: :x:", ":x: :x: :o: :o:",
        ":x: :o: :x: :x:", ":x: :o: :x: :o:", ":x: :o: :o: :x:", ":x: :o: :o: :o:",
        ":o: :x: :x: :x:", ":o: :x: :x: :o:", ":o: :x: :o: :x:", ":o: :x: :o: :o:",
        ":o: :o: :x: :x:", ":o: :o: :x: :o:", ":o: :o: :o: :x:", ":o: :o: :o: :o:",
    ];

    function Scramble() {
        return Scramble[Math.floor(Math.random() * Scramble.length)];
    };

    var Modules = Math.floor(Math.random() * Scramble.length);
    message.channel.send(Scramble[Modules]).then(message => {
    var Random1 =  Math.floor(Math.random() * Scramble.length);
    setTimeout(() => { message.edit(Scramble[Random1]); }, 1000);
    var Random2 =  Math.floor(Math.random() * Scramble.length);
    setTimeout(() => { message.edit(Scramble[Random2]); }, 2000);
    var Random3 =  Math.floor(Math.random() * Scramble.length);
    setTimeout(() => { message.edit(Scramble[Random3]); }, 3000);
    var Random4 =  Math.floor(Math.random() * Scramble.length);
    setTimeout(() => { message.edit(Scramble[Random4]); }, 4000);
    var Random5 =  Math.floor(Math.random() * Scramble.length);
    setTimeout(() => { message.edit(Scramble[Random5]); }, 5000);
    });
};