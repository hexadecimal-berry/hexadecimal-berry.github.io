module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    if(!Args[0]) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: `Mention a Person to Kick`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });
    
    let Users = message.mentions.members.first() || message.guild.members.cache.get(Args[0]);

    if(!Users) return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `That is not a Member of this Server`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    let Reasons = Args.slice(1).join(' ');

    if(!Args[1]) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: `Provide a Reason to Kick`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    if(!Users.kickable) return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You can not Kick this Member due to Higher Rank`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    if(!message.member.permissions.has('KICK_MEMBERS')) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: `You don't have Permission to Execute this Command`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    if(message.author.id === Users.id) return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You can not Kick yourself...`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    }).then((MSG) => {
        setTimeout(() => { MSG.delete(); }, 25000);
    });

    message.mentions.users.map(async USR => {
        const MBR = message.guild.member(USR);

        try { await USR.send({embed: {
            color: 0xFF0000,
            title: 'You were Kicked from ' + message.guild.name + ' for:',
            description: `Reason: **${Reasons}**`,
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }}}); 
        } catch(Err) {
            console.log(Err);
        };

        MBR.kick(Reasons);

        message.channel.send({embed: {
            color: 0x00FF00,
            title: 'Kicking the Member...',
            description: `You've Kicked **${Users}** for: **${Reasons}**`,
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }},
        });
    });
};