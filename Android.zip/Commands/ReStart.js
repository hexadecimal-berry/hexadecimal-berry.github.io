module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    if(message.author.id !== '473107978375921674') return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You don't have Permission to Execute this Command`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
    
    message.channel.send({embed: {
        color: 0xC0C0C0,
        title: 'Stopping the Services',
        description: 'Android is Restarting...',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        Android.destroy();
        
        Android.login(Configs.Token);
    });
};