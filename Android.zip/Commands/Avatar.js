module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    let Users = message.mentions.users.first() || message.author;
    
    message.channel.send({embed: {
        color: 0x00FF00,
        title: 'Showing Avatar for: ' + Users.username,
        image: {
            url: Users.avatarURL(),
        },
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
};