﻿module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    if(message.author.id !== '473107978375921674') return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You don't have Permission to Execute this Command`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });

    try {
        const Codes = Args.join(' ');

        let Evals = eval(Codes);

        if(typeof Evals !== 'string') {
            Evals = require('util').inspect(Evals);
        };
        
        message.channel.send(clean(Evals)).then((MSG) => {
            setTimeout(() => { MSG.delete(); }, 000);
        });
    } catch(Err) {
        message.channel.send({embed: {
            color: 0xFF0000,
            title: '❌ Android Error',
            description: `\`\`\`xl\n${clean(Err)}\n\`\`\``,
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }}
        });
    };
    
    function clean(Texty) {
        if(typeof(Texty) === 'string') {
            return Texty.replace(/`/g, '`' + String.fromCharCode(8203)).replace(/@/g, '@' + String.fromCharCode(8203));
        } else {
            return Texty;
        };
    };
};