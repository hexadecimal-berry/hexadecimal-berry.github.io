module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    function Duration(MS) {
        const Sec = Math.floor((MS / 1000) % 60).toString();
        const Min = Math.floor((MS / (1000 * 60)) % 60).toString();
        const Hrs = Math.floor((MS / (1000 * 60 * 60)) % 60).toString();
        const Day = Math.floor((MS / (1000 * 60 * 60 * 24)) % 60).toString();
        
        return `${Day.padStart(1, '0')} Days, ${Hrs.padStart(1, '0')} Hours, ${Min.padStart(1, '0')} Minutes, ${Sec.padStart(1, '0')} Seconds`;
    };
    
    message.channel.send({embed: {
        color: 0x00FF00,
        title: 'How long the Bot is Running for',
        description: `Android has been Running for: ${Duration(Android.uptime)}`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
};