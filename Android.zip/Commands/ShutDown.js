module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    if(message.author.id !== '473107978375921674') return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You don't have Permission to Execute this Command`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
    
    Android.user.setActivity('Shutting Down...');
    
    message.channel.send({embed: {
        color: 0xC0C0C0,
        title: 'Stopping the Services',
        description: 'Android is now Shutting Down...',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        process.exit();
    });
};