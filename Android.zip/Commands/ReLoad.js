module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);
    
    if(message.author.id !== '473107978375921674') return message.channel.send({embed: {
        color: 0xFF0000,
        title: '❌ Android Error',
        description: `You don't have Permission to Execute this Command`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    });
    
    if(Args.length < 1) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: 'Provide a Command to Reload',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    });

    delete require.cache[require.resolve(`./${Args[0]}.js`)];
    
    message.channel.send({embed: {
        color: 0x00FF00,
        title: 'Reloading a Command...',
        description: `The Command **${Args[0]}.js** has been Reloaded`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    });
};