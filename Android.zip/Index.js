const Discord = require('Discord.js');
const Configs = require('./Configs.json');
const Package = require('./Package.json');

const FSFiles = require('fs');

const YTDLs = require('ytdl-core');

const Android = new Discord.Client();

const Stats = [
    '!Help - Commands',
    'Revision: ' + Configs.BNumber,
    '!Help - Commands',
];

const ErrorMSG = new Discord.MessageEmbed();
ErrorMSG.title = '❌ Android Error';

Android.on('ready', async() => {
    console.log('Android has Started, no Errors has Found');
    
    setInterval(() => {
        const Final = Stats[Math.random() * Stats.length | 0];

        Android.user.setActivity(Final, {
            type: 'PLAYING'
        });

        console.log('Activity set to: ' + Final);
    }, 25000);
});

let Chatter = process.openStdin();

Chatter.addListener('data', Res => {
    let X = Res.toString().trim().split(/ +/g);

    Android.channels.cache.get('691398780980822071').send(X.join(' '));
});

Android.on('message', async message => {
    if(message.channel.type === 'dm') return console.log('\n\
    DMs from: ' + message.author.tag + '\n\
    When was: ' + message.createdAt + '\n\
    Contents: ' + message.content + '');

    console.log('\n\
    Servers: ' + message.guild.name + ' (IDs: ' + message.guild.id + ')\n\
    Channel: ' + message.channel.name + ' (IDs: ' + message.channel.id + ')\n\
    Members: ' + message.author.tag + ' (IDs: ' + message.author.id + ')\n\
    Datings: ' + message.createdAt + '\n\
    Content: ' + message.content + '');

    FSFiles.appendFile('./Chats.txt', '\n\
    Servers: ' + message.guild.name + ' (IDs: ' + message.guild.id + ')\n\
    Channel: ' + message.channel.name + ' (IDs: ' + message.channel.id + ')\n\
    Members: ' + message.author.tag + ' (IDs: ' + message.author.id + ')\n\
    Datings: ' + message.createdAt + '\n\
    Content: ' + message.content + '', (Err) => {
        if(Err) throw Err;
    });
    
    if(message.author.bot) return;

    if(message.content === Configs.Prefix) {
        message.channel.send({embed: {
            color: 0xFF0000,
            title: '❌ Android Error',
            description: 'What did you expect by saying the Prefix',
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }}}).then((MSG) => {
                setTimeout(() => { MSG.delete(); }, 25000);
            });
        return;
    };

    if(message.content.indexOf(Configs.Prefix) !== 0) return;

    if(message.author.id === 000) {
        message.channel.send({embed: {
            color: 0xFF0000,
            title: '❌ Android Error',
            description: 'You are Banned from using Commands',
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }}});
    } else {
        const Args = message.content.slice(Configs.Prefix.length).trim().split(/ +/g);
        
        const CMD = Args.shift().toLowerCase();
        
        try {
            let CMDFile = require(`./Commands/${CMD}.js`);
            console.log('Executed: ' + message, Args);
            CMDFile.run(Android, Configs, message, Package, Args);
            
            message.channel.startTyping();
        } catch(Err) {
            if(message.channel.id !== 000) {
                ErrorMSG.setDescription(`I was unable to find the Command: **${CMD}.js**`);
        } else {
            ErrorMSG.setDescription('UNDEFINED_UNRECOVERABLE_ERROR');
        };

        ErrorMSG.setColor(0xFF0000);
        ErrorMSG.setTimestamp();
        ErrorMSG.setFooter('© TheGreekDev • Revision: ' + Configs.BNumber,
        `${Android.user.avatarURL()}`);
        
        message.channel.send(ErrorMSG).then((MSG) => {
            setTimeout(() => { MSG.delete(); }, 25000);
        });

        if(Err.toString().startsWith('Error: ')) {
            message.channel.stopTyping(); return;
        };
    }};
});

Android.login(Configs.Token);