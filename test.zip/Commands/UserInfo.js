module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    let Users = message.mentions.users.first() || message.author;
    
    message.channel.send({embed: {
        color: 0x00FF00,
        title: 'Showing User Info for: ' + Users.username,
        thumbnail: {
            url: Users.avatarURL(),
        },
        description: `\n\
        **Tag:** ${Users.tag}
        **IDs:** ${Users.id}
        **Bot:** ${Users.bot}
        **Stats:** ${Users.presence.status}
        **Playing:** ${Users.presence.activities}`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
};