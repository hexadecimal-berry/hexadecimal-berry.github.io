module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    let Results;
    
    if(Args.length < 1) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: 'Nothing to Say? Alright then...',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
    
    if(message.mentions.channels.first()) {
        Results = Args.slice(1).join(' ');
        message.channel.send({embed: {
            color: 0x00FF00,
            title: message.author.username + ' Say:',
            description: Results,
        }});
    } else {
        Results = Args.join(' ');
        message.channel.send({embed: {
            color: 0x00FF00,
            title: message.author.username + ' Say:',
            description: Results,
        }});
    };
};