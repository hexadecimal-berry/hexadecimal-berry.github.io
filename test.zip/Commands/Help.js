module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    message.channel.send({embed: {
        color: 0xC0C0C0,
        title: '📬 Check your DMs!',
        description: `I've sent you the Commands`,
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    });
    
    message.author.send({embed: {
        color: 0x00FF00,
        title: 'All the Commands...',
        description: 'This is Work in Progress...',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }},
    });
};