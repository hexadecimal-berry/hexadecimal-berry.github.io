﻿module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    var Pingy = Math.round(Android.ws.ping);
    
    message.channel.send({embed: {
        color: 0xC0C0C0,
        title: `The Bot's Latency`,
        description: 'Checking for Latency...',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}}).then((MSG) => {
            if(Pingy >= 1 && Pingy <= 100) {
                MSG.edit({embed: {
                    color: 0x00FF00,
                    title: `The Bot's Latency`,
                    description: `Pong! **${Pingy} MS** between Server and Client`,
                    timestamp: new Date(),
                    footer: {
                        icon_url: Android.user.avatarURL(),
                        text: '© TheGreekDev • Revision: ' + Configs.BNumber,
                    }}
                });
            } else {
                if(Pingy >= 100 && Pingy <= 250) {
                    MSG.edit({embed: {
                        color: 0xFFFF00,
                        title: `The Bot's Latency`,
                        description: `Pong! **${Pingy} MS** between Server and Client`,
                        timestamp: new Date(),
                        footer: {
                            icon_url: Android.user.avatarURL(),
                            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
                        }}
                    });
                } else {
                    if(Pingy >= 250 && Pingy <= 500) {
                        MSG.edit({embed: {
                            color: 0xFF0000,
                            title: `The Bot's Latency`,
                            description: `Pong! **${Pingy} MS** between Server and Client`,
                            timestamp: new Date(),
                            footer: {
                                icon_url: Android.user.avatarURL(),
                                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
                            }}
                        });
                    };
                };
            };
        });
};