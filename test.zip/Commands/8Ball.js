module.exports.run = async(Android, Configs, message, Package, Args) => {
    setTimeout(() => { message.channel.stopTyping(); }, 2500);

    let Missing = [
        'Do you expect me to have some Modules to read your mind?',
        'Do you expect me to have some Modules to read your mind?',
        'Do you expect me to have some Modules to read your mind?',
    ];

    let Answers = [
        'As I see it, Yes', 'As I see it, Maybe', 'As I see it, No', 'Ask again later', 'Better not tell you now', 'Cannot predict now',
        'Concentrate and ask again later', 'It is Certain', 'My reply is Yes', 'My reply is Maybe', 'My reply is No', 'My Modules say Yes',
        'My Modules say Maybe', 'My Modules say No', 'Signs point to Yes', 'Signs point to Maybe', 'Signs point to No', 'Very doubtful, Yes',
        'Absolutely', 'Answer is unclear, ask later', 'Consult me later', 'Focus and ask again', 'Indications say NaN', 'Positively', '*Sigh*',
        'Looks like Yes', 'Looks like Maybe', 'Looks like No', 'The Stars say Yes', 'The Stars say Maybe', 'The Stars say No', 'Most likely Yes',
        'Most likely Maybe', 'Most likely No', '24 Hours Flu', 'Abducted by Aliens', 'Amnesia', 'Full Moon, Huh?', 'At least I love you', 'Hellno',
        'Ask me if I care', 'Dumb question, ask another please', 'Only in your Dreams', 'Not a chance', 'Ridiculous', 'Yeah, you wish', 'Kidding me',
    ];
    
    if(!Args[1]) return message.channel.send({embed: {
        color: 0xFFFF00,
        title: '⚠ Android Warning',
        description: Missing[Math.floor(Math.random() * Missing.length)],
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    });
    
    message.channel.send({embed: {
        color: 0xC0C0C0,
        title: '🎱 The Magic 8Ball',
        description: 'Thinking...',
        timestamp: new Date(),
        footer: {
            icon_url: Android.user.avatarURL(),
            text: '© TheGreekDev • Revision: ' + Configs.BNumber,
        }}
    }).then((MSG) => {
        setTimeout(() => { MSG.edit({embed: {
            color: 0x00FF00,
            title: '🎱 The Magic 8Ball',
            description: Answers[Math.floor(Math.random() * Answers.length)],
            timestamp: new Date(),
            footer: {
                icon_url: Android.user.avatarURL(),
                text: '© TheGreekDev • Revision: ' + Configs.BNumber,
            }}
        }); }, 500);
    });
};